-------------------------------------------------------------------
Ripped by Centrixe at The Models Resource.
I'm also on DeviantArt! https://www.deviantart.com/centrixe.
-------------------------------------------------------------------
Ripped with Random Talking Bush & Ploaj's Smash Ultimate MaxScript.
Content � Nintendo and/or respective third-party companies.
-------------------------------------------------------------------